#!/bin/sh

dname=`pwd`;
for a in _icache \
_idcache \
rand_large \
rand_small \
_all \
_ctrl \
_mem; do
    for b in *$a.asm; do
        echo $dname/$b;
    done
done
