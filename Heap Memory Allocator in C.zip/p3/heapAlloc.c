////////////////////////////////////////////////////////////////////////////////
// Main File:        heapAlloc.c
// This File:        heapAlloc.c
// Other Files:      NONE
// Semester:         CS 354 Fall 2019
//
// Author:           Jake Wesson
// Email:            jwesson@wisc.edu
// CS Login:         wesson
//
/////////////////////////// OTHER SOURCES OF HELP //////////////////////////////
//                   fully acknowledge and credit all sources of help,
//                   other than Instructors and TAs.
//
// Persons:          NONE 
//
// Online sources:   NONE 
//
//////////////////////////// 80 columns wide ///////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//
// Copyright 2019 Jim Skrentny
// Posting or sharing this file is prohibited, including any changes/additions.
//
///////////////////////////////////////////////////////////////////////////////

#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <stdio.h>
#include <string.h>
#include "heapAlloc.h"

/*
 * This structure serves as the header for each allocated and free block.
 * It also serves as the footer for each free block but only containing size.
 */
typedef struct blockHeader {
        int size_status;
    /*
    * Size of the block is always a multiple of 8.
    * Size is stored in all block headers and free block footers.
    *
    * Status is stored only in headers using the two least significant bits.
    *   Bit0 => least significant bit, last bit
    *   Bit0 == 0 => free block
    *   Bit0 == 1 => allocated block
    *
    *   Bit1 => second last bit 
    *   Bit1 == 0 => previous block is free
    *   Bit1 == 1 => previous block is allocated
    * 
    * End Mark: 
    *  The end of the available memory is indicated using a size_status of 1.
    * 
    * Examples:
    * 
    * 1. Allocated block of size 24 bytes:
    *    Header:
    *      If the previous block is allocated, size_status should be 27
    *      If the previous block is free, size_status should be 25
    * 
    * 2. Free block of size 24 bytes:
    *    Header:
    *      If the previous block is allocated, size_status should be 26
    *      If the previous block is free, size_status should be 24
    *    Footer:
    *      size_status should be 24
    */
} blockHeader;         

/* Global variable - DO NOT CHANGE. It should always point to the first block,
 * i.e., the block at the lowest address.
 */

blockHeader *heapStart = NULL;

blockHeader *prevAllocatedBlock = NULL; // pointer for purpose of NF placement policy

/* 
 * Function for allocating 'size' bytes of heap memory.
 * Argument size: requested size for the payload
 * Returns address of allocated block on success.
 * Returns NULL on failure.
 * This function should:
 * - Check size - Return NULL if not positive or if larger than heap space.
 * - Determine block size rounding up to a multiple of 8 and possibly adding padding as a result.
 * - Use NEXT-FIT PLACEMENT POLICY to chose a free block
 * - Use SPLITTING to divide the chosen free block into two if it is too large.
 * - Update header(s) and footer as needed.
 * Tips: Be careful with pointer arithmetic and scale factors.
 */
void* allocHeap(int size) {
    blockHeader *newBlock = NULL; // the new block whose addr is to be returned at end
    if (size <= 0) { // check for invalid negative or 0 size
	return NULL;
    }

    int blockSize = sizeof(blockHeader) + size; // get new block size
    if (blockSize%8 != 0) { // pad if needed
	blockSize += 8 - blockSize%8; // Ex: if size 13, padding needed is 3, 13%8 = 5, 8 - 5 = 3
    }

    if (prevAllocatedBlock == NULL) { // special case for first allocation
	int freeSize = heapStart->size_status - 2; // know first block has header <heap size>/10, so need to subtract two to get size of block
	if (blockSize > freeSize) { // if needed block size too big, return NULL
	    return NULL;
	}

	newBlock = heapStart; // set newBlock to start of heap
	newBlock->size_status = blockSize + 2 + 1; // make the size status blockSize/11
	prevAllocatedBlock = newBlock; // set prevAllocatedBlock

	blockHeader *movedHeader = (blockHeader*) ((void*)newBlock + blockSize); // new header must be created after block
	
	movedHeader->size_status = freeSize - blockSize + 2;
	
	blockHeader *footer = (blockHeader*) ((void*)movedHeader + freeSize - blockSize - sizeof(blockHeader));

	footer->size_status = freeSize - blockSize;

	return (blockHeader*) newBlock + 1;
    }
    else {
	blockHeader *currBlock = prevAllocatedBlock; // start search at prevAllocatedBlock
	do {

	    int nextBlockDist = currBlock->size_status; // figure out what to add to get to the next block
	    if ((nextBlockDist & 1) == 1) {
		--nextBlockDist;
	    }
	    if ((nextBlockDist & 2) == 2) {
		nextBlockDist -= 2;
	    }

	    if (currBlock->size_status == 1) { // end of heap, wraparound to start
		currBlock = heapStart;
		continue;
	    }
	    if ((currBlock->size_status & 1) == 1) { // if block is allocated, it can be skipped
	        currBlock = (blockHeader*) ((void*)currBlock + nextBlockDist);
	    	continue;
	    }

	    int freeBlockSize = currBlock->size_status - 2; // if block free, check size

	    if (blockSize > freeBlockSize) { // check if block is big enough
		currBlock = (blockHeader*) ((void*)currBlock + nextBlockDist);
		continue;
	    }
	    else { // otherwise place the new block
                currBlock->size_status = blockSize + 2 + 1; // if immidiate coalescing used...
	        // ...then every newly placed block should come immidiately after an allocated one
		newBlock = currBlock;
		if (blockSize == freeBlockSize) { // if the block is perfectly sized...
		    currBlock = (blockHeader*) ((void*)currBlock + blockSize);
		    if (currBlock->size_status != 1) { // check that the next block after newly allocated one...
			  			       // ...isn't end of heap before updating its size_status
		        currBlock->size_status += 2; // ... the only thing that needs to be changed is next header
		    }
		    prevAllocatedBlock = newBlock;
		    return (blockHeader*) newBlock + 1;
		}
		else { // not perfectly sized block case
		    currBlock = (blockHeader*) ((void*)currBlock + blockSize); // set the head of new block
		    currBlock->size_status = freeBlockSize - blockSize + 2;
		    blockHeader *footer = (blockHeader*) ((void*)currBlock + freeBlockSize - blockSize - sizeof(blockHeader)); // set the footer
		    footer->size_status = freeBlockSize - blockSize;
		    prevAllocatedBlock = newBlock;
		    return (blockHeader*) newBlock + 1; 
		}
	    }

	} while (currBlock != prevAllocatedBlock); // when currBlock == prevAllocatedBlock again, it means the whole heap has been traversed
    }
    return NULL;
}

/* 
 * Function for freeing up a previously allocated block.
 * Argument ptr: address of the block to be freed up.
 * Returns 0 on success.
 * Returns -1 on failure.
 * This function should:
 * - Return -1 if ptr is NULL.
 * - Return -1 if ptr is not p’:a multiple of 8.
 * - Return -1 if ptr is outside of the heap space.
 * - Return -1 if ptr block is already freed.
 * - USE IMMEDIATE COALESCING if one or both of the adjacent neighbors are free.
 * - Update header(s) and footer as needed.
 */                    
int freeHeap(void *ptr) {
    int moveNF = 0; // boolean to tell if the last placed block was freed

    if (ptr == NULL) {
    	return -1;
    }

    if (((int)ptr)%8 != 0) {
	return -1;
    }

    blockHeader *endHeap = heapStart; 
    while (endHeap->size_status != 1) { // iterate through heap to find the end...
	int dist = endHeap->size_status;
	if ((endHeap->size_status & 1) == 1) {
	    dist -= 1;
	}
	if ((endHeap->size_status & 2) == 2) {
	    dist -= 2;
	}
	endHeap = (blockHeader*) ((void*)endHeap + dist);
    }
    if (ptr < ((void*)heapStart) || ptr > ((void*)endHeap)) { // ...so that the address can be checked for validity
	return -1;
    }

    blockHeader *theBlock = (blockHeader*) ((void*)ptr - sizeof(blockHeader));
    if ((theBlock->size_status & 1) == 0) { // check block isn't already free
	return -1;
    }

    if (theBlock == prevAllocatedBlock) { // indicate NF pointer might move since block to be removed was last allocated one
	++moveNF;
    }

    // Four cases for removing: no coalescing required(1), coalesce following block(2), coalesce previous block(3), coalesce both(4)
    theBlock->size_status -= 1; // needed for 1 and 2, and doesn't affect 3 and 4

    int nextBlockDist = theBlock->size_status;
    int prevBlockFree = 1; // boolean to tell if previous block free declared here to save a check later
    if (nextBlockDist%8 != 0) {
	nextBlockDist -= 2;
	--prevBlockFree;
    }

    int newFreeBlockSize = nextBlockDist; // no matter what, the resultant free block will at least be the size of the block being freed

    blockHeader *nextBlock = (blockHeader*) ((void*)theBlock + nextBlockDist);
    if ((nextBlock->size_status & 1) == 0) { // check if next block is allocated or not
	newFreeBlockSize += nextBlock->size_status - 2; // 2 is always subtracted since we know the current block is currently allocated, so p-bit of this is 1
	if (nextBlock == prevAllocatedBlock) {
	    ++moveNF;
	}
    }
    else { // if next block allocated, update the p-bit
	if (nextBlock->size_status != 1) {
	    nextBlock->size_status -= 2;
	}
    }

    if (prevBlockFree) {
	blockHeader *prevBlock = (blockHeader*) ((void*)theBlock - sizeof(blockHeader)); // put footer in here...
	prevBlock = (blockHeader*) ((void*)prevBlock - prevBlock->size_status + sizeof(blockHeader)); // ...and use it to get to actual block head
	int prevBlockSize = prevBlock->size_status - 2; // due to immidiate coalescing, any block before a free block is known to be allocated
	newFreeBlockSize += prevBlockSize;
	theBlock = prevBlock;
    }
    // there wasn't a prevAllocatedBlock check in this one since the coalesced block would still be at the same location in prevAllocatedBlock

    theBlock->size_status = newFreeBlockSize + 2; // add 2 since previous block guaranteed to be allocated due to immidiate coalescing

    blockHeader *footer = (blockHeader*) ((void*)theBlock + newFreeBlockSize - sizeof(blockHeader));
    footer->size_status = newFreeBlockSize; // set new footer
    if (moveNF) { // update prevAllocatedBlock if it was coalesced
	prevAllocatedBlock = theBlock;
    }
    return 0;
}

/*
 * Function used to initialize the memory allocator.
 * Intended to be called ONLY once by a program.
 * Argument sizeOfRegion: the size of the heap space to be allocated.
 * Returns 0 on success.
 * Returns -1 on failure.
 */                    
int initHeap(int sizeOfRegion) {         

    static int allocated_once = 0; //prevent multiple initHeap calls

    int pagesize;  // page size
    int padsize;   // size of padding when heap size not a multiple of page size
    int allocsize; // size of requested allocation including padding
    void* mmap_ptr; // pointer to memory mapped area
    int fd;

    blockHeader* endMark;
  
    if (0 != allocated_once) {
        fprintf(stderr, 
        "Error:mem.c: InitHeap has allocated space during a previous call\n");
        return -1;
    }
    if (sizeOfRegion <= 0) {
        fprintf(stderr, "Error:mem.c: Requested block size is not positive\n");
        return -1;
    }

    // Get the pagesize
    pagesize = getpagesize();

    // Calculate padsize as the padding required to round up sizeOfRegion 
    // to a multiple of pagesize
    padsize = sizeOfRegion % pagesize;
    padsize = (pagesize - padsize) % pagesize;

    allocsize = sizeOfRegion + padsize;

    // Using mmap to allocate memory
    fd = open("/dev/zero", O_RDWR);
    if (-1 == fd) {
        fprintf(stderr, "Error:mem.c: Cannot open /dev/zero\n");
        return -1;
    }
    mmap_ptr = mmap(NULL, allocsize, PROT_READ | PROT_WRITE, MAP_PRIVATE, fd, 0);
    if (MAP_FAILED == mmap_ptr) {
        fprintf(stderr, "Error:mem.c: mmap cannot allocate space\n");
        allocated_once = 0;
        return -1;
    }
  
    allocated_once = 1;

    // for double word alignment and end mark
    allocsize -= 8;

    // Initially there is only one big free block in the heap.
    // Skip first 4 bytes for double word alignment requirement.
    heapStart = (blockHeader*) mmap_ptr + 1;

    // Set the end mark
    endMark = (blockHeader*)((void*)heapStart + allocsize);
    endMark->size_status = 1;

    // Set size in header
    heapStart->size_status = allocsize;

    // Set p-bit as allocated in header
    // note a-bit left at 0 for free
    heapStart->size_status += 2;

    // Set the footer
    blockHeader *footer = (blockHeader*) ((char*)heapStart + allocsize - 4);
    footer->size_status = allocsize;
    return 0;
}         
                 
/* 
 * Function to be used for DEBUGGING to help you visualize your heap structure.
 * Prints out a list of all the blocks including this information:
 * No.      : serial number of the block 
 * Status   : free/used (allocated)
 * Prev     : status of previous block free/used (allocated)
 * t_Begin  : address of the first byte in the block (where the header starts) 
 * t_End    : address of the last byte in the block 
 * t_Size   : size of the block as stored in the block header
 */                     
void DumpMem() {  

    int counter;
    char status[5];
    char p_status[5];
    char *t_begin = NULL;
    char *t_end   = NULL;
    int t_size;

    blockHeader *current = heapStart;
    counter = 1;

    int used_size = 0;
    int free_size = 0;
    int is_used   = -1;

    fprintf(stdout, "************************************Block list***\
                    ********************************\n");
    fprintf(stdout, "No.\tStatus\tPrev\tt_Begin\t\tt_End\t\tt_Size\n");
    fprintf(stdout, "-------------------------------------------------\
                    --------------------------------\n");
  
    while (current->size_status != 1) {
        t_begin = (char*)current;
        t_size = current->size_status;
    
        if (t_size & 1) {
            // LSB = 1 => used block
            strcpy(status, "used");
            is_used = 1;
            t_size = t_size - 1;
        } else {
            strcpy(status, "Free");
            is_used = 0;
        }

        if (t_size & 2) {
            strcpy(p_status, "used");
            t_size = t_size - 2;
        } else {
            strcpy(p_status, "Free");
        }

        if (is_used) 
            used_size += t_size;
        else 
            free_size += t_size;

        t_end = t_begin + t_size - 1;
    
        fprintf(stdout, "%d\t%s\t%s\t0x%08lx\t0x%08lx\t%d\n", counter, status, 
        p_status, (unsigned long int)t_begin, (unsigned long int)t_end, t_size);
    
        current = (blockHeader*)((char*)current + t_size);
        counter = counter + 1;
    }

    fprintf(stdout, "---------------------------------------------------\
                    ------------------------------\n");
    fprintf(stdout, "***************************************************\
                    ******************************\n");
    fprintf(stdout, "Total used size = %d\n", used_size);
    fprintf(stdout, "Total free size = %d\n", free_size);
    fprintf(stdout, "Total size = %d\n", used_size + free_size);
    fprintf(stdout, "***************************************************\
                    ******************************\n");
    fflush(stdout);

    return;  
}  
