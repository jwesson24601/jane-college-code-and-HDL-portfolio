#include <stdio.h>  
#include <stdlib.h>
#include <string.h>     

char *COMMA = ",";  

/** 
 * Retrieves from the first line of the input file,
 * the size of the board (number of rows and columns).
 * 
 * fp: file pointer for input file
 * size: pointer to size
 */
void get_dimensions(FILE *fp, int *size) {      
    char *line = NULL;
    size_t len = 0;
    if (getline(&line, &len, fp) == -1) {
        printf("Error in reading the file\n");
        exit(1);
    }

    char *token = NULL;
    token = strtok(line, COMMA);
    *size = atoi(token);
}   


/**
 * Returns 1 if and only if the board is in a valid state.
 * Otherwise returns 0.
 * 
 * board: heap allocated 2D board
 * size: number of rows and columns
 */
int n_in_a_row(int **board, int size) {
    // Checking number of Xs and Os
    int xCount = 0; // number of Xs
    int oCount = 0; // number of Os
    for (int i=0; i < size; ++i) { // iterate through array
	for (int j=0; j < size; ++j) {
	    if (*(*(board+i)+j) == 1) { // check if x, o, or unfilled
	        ++xCount;		// increment appropriate counter
	    }
	    else if (*(*(board+i)+j) == 2) {
		++oCount;
	    }
        }
    } 
    if (xCount - oCount > 1 || xCount - oCount < 0) {
	return 0;
    }

    int vicType = 0; // what type of victory occurred, 1 if X, 2 if O, 0 if no victory
    // this is needed since if there's one more X than O and Os won, the board is
    // invalid, and if there are the same number of Xs and Os and Xs won, the board is
    // also invalid

    //Checking only one or no victories
    //checking for horizontal victories
    int horVic = 0; // total number of horizontal victories
    int vicRow; // which row victory occurred in (only a valid value if one row victory)
    int rowPassed = 1; // basically a boolean that says whether the current row was a victory or not
    for (int i=0; i < size; ++i) {
	int currVal; // current value to check
	int prevVal = **(board+i); // previous value, assigned first value in row
	if (prevVal == 0) { // if first value is 0, the row is not a victory 
	    continue;	    // so the row is skipped and we move to the next one
	}
        for (int j=1; j < size; ++j) { // first value in row X or O, start checking row
	    currVal = *(*(board+i)+j); // access the next element in one of the subarrays 
            if (prevVal != currVal) { // test if the values match
		rowPassed = 0; // if they don't, set the psuedo-boolean to 0 to indicate row failed
                break; // and exit the loop
            }
	    prevVal = currVal; // if the row didn't fail, move to next set of elements
        }
	if (rowPassed) { // test if the row was a victory
	    vicRow = i; // put the row into vicRow if it was and
	    ++horVic; // increment number of horizontal victories
	}
	else {
	    rowPassed = 1; // set back to initial value for next iteration
	}
    }
    if (horVic > 1) { // check there isn't more than one horizontal victory
	return 0;
    }
    if (horVic != 0) { // if there is a horizontal victory
	vicType = **(board+vicRow); // then the type of victory for whole board is X or O
    }
    // If exactly one victory of Xs or Os occurs, then we know that there are no other
    // victories of the other type left on the board, since any other type would intersect
    // with this row, hence why vicType can be determined here if there's exactly one 
    // horizontal victory

    // checking for vertical victories
    int vertVic = 0; // total number of vertical victores
    int vicCol; // which column victory occurred in
    int colPassed = 1; // a boolean that says whether current column was a victory or not
    for (int i=0; i < size; ++i) { // similar to horizontal except instead of going down a subarray...
        int currVal;		   // ...you go across subarrays at the same index
        int prevVal = *(*board+i); // starts at first subarray index i..
        if (prevVal == 0) {
            continue;
        }
        for (int j=1; j < size; ++j) {
            currVal = *(*(board+j)+i); // ...and the value for comparison is in the next subarrary at the same index
            if (prevVal != currVal) {  // honestly, I thought it was funny how just switching i and j worked
                colPassed = 0;
                break;
            }
            prevVal = currVal;
        }
	if (colPassed) { // same check here as on horizontal
	    vicCol = i;
            ++vertVic;
	}
	else {
	    colPassed = 1;
	}
    }
    if (vertVic > 1) { // checks for same things as horizontal, only on vert victory
	return 0;
    }
    if (vertVic != 0) { // and determine type if one vertical victory
        vicType = *(*board+vicCol);
    }

    // checking left diagonal (0, 0) to (size-1, size-1)
    int currVal;
    int prevVal = **board; // **board == board[0][0]
    int diagVicL = 1; // boolean to tell if diagonal passed
    if (prevVal == 0) { // if corner value is 0
       diagVicL = 0; // then this diagonal doesn't need checking
    }
    if (diagVicL) {
        for (int i=1; i < size; ++i) { // begin the check since corner was an O or X
            currVal = *(*(board+i)+i); // check if (0,0)==(1,1)==(2,2)==... one pair at a time
	    if (prevVal != currVal) {
	        --diagVicL;
	        break;
            }
            prevVal = currVal;
        }
    }
    if (diagVicL == 1) { // victory type assigner for left diagonal
	vicType = **board;
    }

    // checking right diagonal (0, size-1) to  (size-1, 0)
    prevVal = **(board+(size-1)); // similar setup as left diagonal, but starting at other corner...
    int diagVicR = 1; // boolean to tell if diagonal passed but for the other one
    if (prevVal == 0) {
        diagVicR = 0;
    }
    if (diagVicR) { // very similar setup to other diagonal, unsurprisingly
        for (int i=1; i < size; ++i) {
            currVal = *(*(board+i)+(size-1-i)); // ...and it checks if (0, size-1)==(1, size-2)==... one pair at a time
            if (prevVal != currVal) {
                --diagVicR;
                break;
            }
            prevVal = currVal;
	}
    }
    if (diagVicR == 1) { // victory type assigner for right diagonal
	vicType = **(board+(size-1));
    }

    // testing that there's one more X than the number of Os if X won...
    if ((vicType == 1) && ((xCount - oCount) == 0)) {
	return 0;
    }
    // ...or if there's the same number of Xs and Os if O won...
    else if ((vicType == 2) && ((xCount - oCount) == 1)) {
	return 0;
    }

    int totalVic = diagVicR + diagVicL + horVic + vertVic; // total number of victories of any type
    // Some cases of multiple victories are allowed due to being able to complete rows in different
    // directions with one X (or O), however, only if there are 3 or 4 victories are there ways to
    // have victories in multiple directions that are invalid
    // Hence, if totalVic is 0, 1, or 2, then we can confirm it to be valid by this point
    if (totalVic == 0 || totalVic == 1 || totalVic == 2) {
	return 1;
    }
    // There are 3 ways to win with three victories, both diagonals and either horizontal or vertical
    // or both horizontal and vertical, and one diagonal
    else if (totalVic == 3) {
	// for the both diagonals intersect case, then one move can only cause 3 victories if the 
	// dimensions are odd (since that's the only way the diagonals intersect at one square)
	// and if the horizontal or vertical victory passes through the middle of the board,
	// these conditions are written into the if and first else if
	if ((diagVicR == 1) && (diagVicL == 1) && (horVic == 1) && (size%2 == 1) && (vicRow == (size/2))) {
	    return 1;
	}
	else if ((diagVicR == 1) && (diagVicL == 1) && (vertVic == 1) && (size%2 == 1) && (vicCol == (size/2))) {
	    return 1;
	}
	// if you have both horizontal and vertical victories, then one move can only cause 3 victories
	// if the horizontal and vertical victory happened at the same indexed row and column, otherwise
	// the most you could achieve simultaneously is 2
	else if ((horVic == 1) && (vertVic == 1) && (vicRow == vicCol)) {
	    return 1;
	}
	else { 
	    return 0;
	}
    }
    // only way to achieve 4 victories simultaneously is to have a victory in each direction and
    // the only way to place one X (or O) and have this occur is to have odd dimensions so the
    // diagonals can intersect and to have both the index of the horizontal and vertical victory
    // row be exactly in the middle of the board
    else if (totalVic == 4) {
	if ((size%2 == 1) && (vicRow == vicCol) && (vicRow == (size/2))) {
	    return 1;
	}
	else {
	    return 0;
	}
    }
    else { // this else shouldn't ever be encountered unless something's gone wrong, since there
	   // should be no way to have more than one victory in each direction and reach the 
	   // final if statement here, in case something goes awry though, I want to know
	printf("Something's gone wrong!\n");
	return 0;
    }
}     


/**
 * This program prints Valid if the input file contains
 * a game board with either 1 or no winners; and where
 * there is at most 1 more X than O.
 * 
 * argc: CLA count
 * argv: CLA value
 */
int main(int argc, char *argv[]) {              

    // Check if number of command-line arguments is correct.
    if (argc != 2) {
	printf("Usage: ./n_in_a_row <input_filename>\n");
	exit(1);
    }

    //Open the file and check if it opened successfully.
    FILE *fp = fopen(*(argv + 1), "r");
    if (fp == NULL) {
        printf("Cannot open file for reading\n");
        exit(1);
    }


    //Declare local variables.
    int size;


    // Call get_dimensions to retrieve the board size
    int *sizeptr = &size; // pointer to size so get_dimensions can change size as implemented
    get_dimensions(fp,sizeptr);
    // Dynamically allocate a 2D array of dimensions retrieved above.
    int **board = malloc(size*sizeof(int)); // the array that holds the board
    if (board == NULL) {
	printf("Error while allocating heap memory for an array that contains subarrays for 2D array\n");
    }
    for (int i=0; i < size; ++i) {
	*(board+i) = malloc(size*sizeof(int));
	if (*(board+i) == NULL) {
	    printf("Error while allocating heap memory for a subarray in a 2D array\n");
	}
    }

    //Read the file line by line.
    //Tokenize each line wrt comma to store the values in your 2D array.
    char *line = NULL;
    size_t len = 0;
    char *token = NULL;
    for (int i = 0; i < size; i++) {

        if (getline(&line, &len, fp) == -1) {
            printf("Error while reading the file\n");
            exit(1);
        }

        token = strtok(line, COMMA);
        for (int j = 0; j < size; j++) {
	    *(*(board+i)+j) = atoi(token); // initialize 2D array with values from file
            token = strtok(NULL, COMMA);
        }
    }

    // Call the function n_in_a_row and print the appropriate
    // output depending on the function's return value.
    if (n_in_a_row(board, size)) {
	printf("valid\n");
    }
    else {
	printf("invalid\n");
    }

    // Free all dynamically allocated memory in reverse order
    for (int i=size-1; i>=0; --i) {
	free(*(board+i));
    }
    free(board);

    //Close the file.
    if (fclose(fp) != 0) {
        printf("Error while closing the file\n");
        exit(1);
    } 

    return 0;       
}   
